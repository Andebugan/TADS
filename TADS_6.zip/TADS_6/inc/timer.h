#ifndef __TIMER_H__
#define __TIMER_H__

#include <stdint.h>
#include <inttypes.h>
#include "timer.h"

uint64_t proc_tick(void);

#endif